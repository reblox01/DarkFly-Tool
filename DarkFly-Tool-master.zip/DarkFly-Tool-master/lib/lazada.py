#!/usr/bin/python
# bomber lazada || 23-12-2017
# gunakan ini sebagai pembelajaran saja!
import lazada_bomber
#    __                    __
#   / /_  ____  ____ ___  / /_  ___  _____
#  / __ \/ __ \/ __ `__ \/ __ \/ _ \/ ___/
# / /_/ / /_/ / / / / / / /_/ /  __/ /
#/_.___/\____/_/ /_/ /_/_.___/\___/_/
#           /_/thePriVat bomber lazada